#pragma once
#define Vmax 20

namespace Tarea1RonaldAvila1010820 {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace System::IO;

	/// <summary>
	/// Resumen de MyForm
	/// </summary>
	public ref class MyForm : public System::Windows::Forms::Form
	{
	public:
		MyForm(void)
		{
			InitializeComponent();
			//
			//TODO: agregar c�digo de constructor aqu�
			//
		}

	protected:
		/// <summary>
		/// Limpiar los recursos que se est�n usando.
		/// </summary>
		~MyForm()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::TabControl^ tabControl1;
	protected:
	private: System::Windows::Forms::TabPage^ tpEjercicio1;
	private: System::Windows::Forms::Button^ btnCalcular;
	private: System::Windows::Forms::Label^ label5;
	private: System::Windows::Forms::Label^ label4;
	private: System::Windows::Forms::TextBox^ txtResultado;
	private: System::Windows::Forms::TextBox^ txtMultiplicador;
	private: System::Windows::Forms::TextBox^ txtMultiplicando;
	private: System::Windows::Forms::Label^ label3;
	private: System::Windows::Forms::Label^ label2;
	private: System::Windows::Forms::Label^ label1;
	private: System::Windows::Forms::TabPage^ tpEjercicio2;
	private: System::Windows::Forms::TabPage^ tpEjercicio3;
	private: System::Windows::Forms::TabPage^ tpEjercicio4;
	private: System::Windows::Forms::Button^ btnSalir;
	private: System::Windows::Forms::Button^ btnIterativa;
	private: System::Windows::Forms::Button^ btnGenerar;

	private: System::Windows::Forms::TextBox^ txtColumnas;
	private: System::Windows::Forms::TextBox^ txtFilas;
	private: System::Windows::Forms::DataGridView^ dgvDeterminante;

	private: System::Windows::Forms::Label^ label8;
	private: System::Windows::Forms::Label^ label7;
	private: System::Windows::Forms::Label^ label6;
	private: System::Windows::Forms::GroupBox^ Importar;
	private: System::Windows::Forms::Button^ btnImportar;
	private: System::Windows::Forms::TextBox^ txtDireccion;
	private: System::Windows::Forms::GroupBox^ groupBox1;
	private: System::Windows::Forms::ListBox^ BancoPalabras;
	private: System::Windows::Forms::Button^ btnComprobar;
	private: System::Windows::Forms::TextBox^ txtDireccionArchivo;

	private: System::Windows::Forms::Button^ btnImportartxt;
	private: System::Windows::Forms::Label^ label10;
	private: System::Windows::Forms::Label^ label9;
	private: System::Windows::Forms::OpenFileDialog^ ofdImportar;



	private:
		/// <summary>
		/// Variable del dise�ador necesaria.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// M�todo necesario para admitir el Dise�ador. No se puede modificar
		/// el contenido de este m�todo con el editor de c�digo.
		/// </summary>
		void InitializeComponent(void)
		{
			this->tabControl1 = (gcnew System::Windows::Forms::TabControl());
			this->tpEjercicio1 = (gcnew System::Windows::Forms::TabPage());
			this->btnIterativa = (gcnew System::Windows::Forms::Button());
			this->btnCalcular = (gcnew System::Windows::Forms::Button());
			this->label5 = (gcnew System::Windows::Forms::Label());
			this->label4 = (gcnew System::Windows::Forms::Label());
			this->txtResultado = (gcnew System::Windows::Forms::TextBox());
			this->txtMultiplicador = (gcnew System::Windows::Forms::TextBox());
			this->txtMultiplicando = (gcnew System::Windows::Forms::TextBox());
			this->label3 = (gcnew System::Windows::Forms::Label());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->tpEjercicio2 = (gcnew System::Windows::Forms::TabPage());
			this->BancoPalabras = (gcnew System::Windows::Forms::ListBox());
			this->btnComprobar = (gcnew System::Windows::Forms::Button());
			this->txtDireccionArchivo = (gcnew System::Windows::Forms::TextBox());
			this->btnImportartxt = (gcnew System::Windows::Forms::Button());
			this->label10 = (gcnew System::Windows::Forms::Label());
			this->label9 = (gcnew System::Windows::Forms::Label());
			this->tpEjercicio3 = (gcnew System::Windows::Forms::TabPage());
			this->Importar = (gcnew System::Windows::Forms::GroupBox());
			this->btnImportar = (gcnew System::Windows::Forms::Button());
			this->txtDireccion = (gcnew System::Windows::Forms::TextBox());
			this->groupBox1 = (gcnew System::Windows::Forms::GroupBox());
			this->label8 = (gcnew System::Windows::Forms::Label());
			this->label7 = (gcnew System::Windows::Forms::Label());
			this->txtFilas = (gcnew System::Windows::Forms::TextBox());
			this->btnGenerar = (gcnew System::Windows::Forms::Button());
			this->txtColumnas = (gcnew System::Windows::Forms::TextBox());
			this->dgvDeterminante = (gcnew System::Windows::Forms::DataGridView());
			this->label6 = (gcnew System::Windows::Forms::Label());
			this->tpEjercicio4 = (gcnew System::Windows::Forms::TabPage());
			this->btnSalir = (gcnew System::Windows::Forms::Button());
			this->ofdImportar = (gcnew System::Windows::Forms::OpenFileDialog());
			this->tabControl1->SuspendLayout();
			this->tpEjercicio1->SuspendLayout();
			this->tpEjercicio2->SuspendLayout();
			this->tpEjercicio3->SuspendLayout();
			this->Importar->SuspendLayout();
			this->groupBox1->SuspendLayout();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->dgvDeterminante))->BeginInit();
			this->SuspendLayout();
			// 
			// tabControl1
			// 
			this->tabControl1->Controls->Add(this->tpEjercicio1);
			this->tabControl1->Controls->Add(this->tpEjercicio2);
			this->tabControl1->Controls->Add(this->tpEjercicio3);
			this->tabControl1->Controls->Add(this->tpEjercicio4);
			this->tabControl1->Location = System::Drawing::Point(13, 13);
			this->tabControl1->Name = L"tabControl1";
			this->tabControl1->SelectedIndex = 0;
			this->tabControl1->Size = System::Drawing::Size(948, 437);
			this->tabControl1->TabIndex = 0;
			// 
			// tpEjercicio1
			// 
			this->tpEjercicio1->Controls->Add(this->btnIterativa);
			this->tpEjercicio1->Controls->Add(this->btnCalcular);
			this->tpEjercicio1->Controls->Add(this->label5);
			this->tpEjercicio1->Controls->Add(this->label4);
			this->tpEjercicio1->Controls->Add(this->txtResultado);
			this->tpEjercicio1->Controls->Add(this->txtMultiplicador);
			this->tpEjercicio1->Controls->Add(this->txtMultiplicando);
			this->tpEjercicio1->Controls->Add(this->label3);
			this->tpEjercicio1->Controls->Add(this->label2);
			this->tpEjercicio1->Controls->Add(this->label1);
			this->tpEjercicio1->Location = System::Drawing::Point(4, 22);
			this->tpEjercicio1->Name = L"tpEjercicio1";
			this->tpEjercicio1->Padding = System::Windows::Forms::Padding(3);
			this->tpEjercicio1->Size = System::Drawing::Size(940, 411);
			this->tpEjercicio1->TabIndex = 0;
			this->tpEjercicio1->Text = L"Ejercicio 1";
			this->tpEjercicio1->UseVisualStyleBackColor = true;
			// 
			// btnIterativa
			// 
			this->btnIterativa->Location = System::Drawing::Point(491, 240);
			this->btnIterativa->Name = L"btnIterativa";
			this->btnIterativa->Size = System::Drawing::Size(139, 46);
			this->btnIterativa->TabIndex = 9;
			this->btnIterativa->Text = L"Calcular en forma iterativa";
			this->btnIterativa->UseVisualStyleBackColor = true;
			this->btnIterativa->Click += gcnew System::EventHandler(this, &MyForm::button1_Click);
			// 
			// btnCalcular
			// 
			this->btnCalcular->Location = System::Drawing::Point(491, 156);
			this->btnCalcular->Name = L"btnCalcular";
			this->btnCalcular->Size = System::Drawing::Size(139, 46);
			this->btnCalcular->TabIndex = 8;
			this->btnCalcular->Text = L"Calcular en forma recursiva";
			this->btnCalcular->UseVisualStyleBackColor = true;
			this->btnCalcular->Click += gcnew System::EventHandler(this, &MyForm::btnCalcular_Click);
			// 
			// label5
			// 
			this->label5->AutoSize = true;
			this->label5->Location = System::Drawing::Point(711, 219);
			this->label5->Name = L"label5";
			this->label5->Size = System::Drawing::Size(13, 13);
			this->label5->TabIndex = 7;
			this->label5->Text = L"=";
			// 
			// label4
			// 
			this->label4->AutoSize = true;
			this->label4->Location = System::Drawing::Point(380, 219);
			this->label4->Name = L"label4";
			this->label4->Size = System::Drawing::Size(14, 13);
			this->label4->TabIndex = 6;
			this->label4->Text = L"X";
			// 
			// txtResultado
			// 
			this->txtResultado->Enabled = false;
			this->txtResultado->Location = System::Drawing::Point(810, 216);
			this->txtResultado->Name = L"txtResultado";
			this->txtResultado->Size = System::Drawing::Size(100, 20);
			this->txtResultado->TabIndex = 5;
			// 
			// txtMultiplicador
			// 
			this->txtMultiplicador->Location = System::Drawing::Point(252, 292);
			this->txtMultiplicador->Name = L"txtMultiplicador";
			this->txtMultiplicador->Size = System::Drawing::Size(100, 20);
			this->txtMultiplicador->TabIndex = 4;
			// 
			// txtMultiplicando
			// 
			this->txtMultiplicando->Location = System::Drawing::Point(252, 134);
			this->txtMultiplicando->Name = L"txtMultiplicando";
			this->txtMultiplicando->Size = System::Drawing::Size(100, 20);
			this->txtMultiplicando->TabIndex = 3;
			// 
			// label3
			// 
			this->label3->AutoSize = true;
			this->label3->Location = System::Drawing::Point(34, 295);
			this->label3->Name = L"label3";
			this->label3->Size = System::Drawing::Size(195, 13);
			this->label3->TabIndex = 2;
			this->label3->Text = L"Ingrese el segundo factor (Multiplicador)";
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Location = System::Drawing::Point(34, 137);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(185, 13);
			this->label2->TabIndex = 1;
			this->label2->Text = L"Ingrese el primer factor (Multiplicando)";
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Font = (gcnew System::Drawing::Font(L"MV Boli", 18, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label1->Location = System::Drawing::Point(176, 18);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(572, 31);
			this->label1->TabIndex = 0;
			this->label1->Text = L"Multiplicaci�n de dos n�meros usando sumas ";
			// 
			// tpEjercicio2
			// 
			this->tpEjercicio2->Controls->Add(this->BancoPalabras);
			this->tpEjercicio2->Controls->Add(this->btnComprobar);
			this->tpEjercicio2->Controls->Add(this->txtDireccionArchivo);
			this->tpEjercicio2->Controls->Add(this->btnImportartxt);
			this->tpEjercicio2->Controls->Add(this->label10);
			this->tpEjercicio2->Controls->Add(this->label9);
			this->tpEjercicio2->Location = System::Drawing::Point(4, 22);
			this->tpEjercicio2->Name = L"tpEjercicio2";
			this->tpEjercicio2->Padding = System::Windows::Forms::Padding(3);
			this->tpEjercicio2->Size = System::Drawing::Size(940, 411);
			this->tpEjercicio2->TabIndex = 1;
			this->tpEjercicio2->Text = L"Ejercicio 2";
			this->tpEjercicio2->UseVisualStyleBackColor = true;
			// 
			// BancoPalabras
			// 
			this->BancoPalabras->FormattingEnabled = true;
			this->BancoPalabras->Location = System::Drawing::Point(622, 74);
			this->BancoPalabras->Name = L"BancoPalabras";
			this->BancoPalabras->Size = System::Drawing::Size(251, 303);
			this->BancoPalabras->TabIndex = 5;
			// 
			// btnComprobar
			// 
			this->btnComprobar->Location = System::Drawing::Point(109, 236);
			this->btnComprobar->Name = L"btnComprobar";
			this->btnComprobar->Size = System::Drawing::Size(123, 46);
			this->btnComprobar->TabIndex = 4;
			this->btnComprobar->Text = L"Comprobar";
			this->btnComprobar->UseVisualStyleBackColor = true;
			// 
			// txtDireccionArchivo
			// 
			this->txtDireccionArchivo->Enabled = false;
			this->txtDireccionArchivo->Location = System::Drawing::Point(109, 139);
			this->txtDireccionArchivo->Name = L"txtDireccionArchivo";
			this->txtDireccionArchivo->Size = System::Drawing::Size(227, 20);
			this->txtDireccionArchivo->TabIndex = 3;
			// 
			// btnImportartxt
			// 
			this->btnImportartxt->Location = System::Drawing::Point(6, 139);
			this->btnImportartxt->Name = L"btnImportartxt";
			this->btnImportartxt->Size = System::Drawing::Size(97, 23);
			this->btnImportartxt->TabIndex = 2;
			this->btnImportartxt->Text = L"Importar";
			this->btnImportartxt->UseVisualStyleBackColor = true;
			this->btnImportartxt->Click += gcnew System::EventHandler(this, &MyForm::btnImportartxt_Click);
			// 
			// label10
			// 
			this->label10->AutoSize = true;
			this->label10->Location = System::Drawing::Point(3, 113);
			this->label10->Name = L"label10";
			this->label10->Size = System::Drawing::Size(100, 13);
			this->label10->TabIndex = 1;
			this->label10->Text = L"Importar archivo .txt";
			// 
			// label9
			// 
			this->label9->AutoSize = true;
			this->label9->Font = (gcnew System::Drawing::Font(L"MV Boli", 18, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label9->Location = System::Drawing::Point(218, 22);
			this->label9->Name = L"label9";
			this->label9->Size = System::Drawing::Size(465, 31);
			this->label9->TabIndex = 0;
			this->label9->Text = L"Comprobaci�n palabras pal�ndromas: ";
			// 
			// tpEjercicio3
			// 
			this->tpEjercicio3->Controls->Add(this->Importar);
			this->tpEjercicio3->Controls->Add(this->groupBox1);
			this->tpEjercicio3->Controls->Add(this->dgvDeterminante);
			this->tpEjercicio3->Controls->Add(this->label6);
			this->tpEjercicio3->Location = System::Drawing::Point(4, 22);
			this->tpEjercicio3->Name = L"tpEjercicio3";
			this->tpEjercicio3->Size = System::Drawing::Size(940, 411);
			this->tpEjercicio3->TabIndex = 2;
			this->tpEjercicio3->Text = L"Ejercicio 3";
			this->tpEjercicio3->UseVisualStyleBackColor = true;
			// 
			// Importar
			// 
			this->Importar->Controls->Add(this->btnImportar);
			this->Importar->Controls->Add(this->txtDireccion);
			this->Importar->Location = System::Drawing::Point(3, 270);
			this->Importar->Name = L"Importar";
			this->Importar->Size = System::Drawing::Size(385, 109);
			this->Importar->TabIndex = 10;
			this->Importar->TabStop = false;
			this->Importar->Text = L"Importar Matriz";
			// 
			// btnImportar
			// 
			this->btnImportar->Location = System::Drawing::Point(9, 33);
			this->btnImportar->Name = L"btnImportar";
			this->btnImportar->Size = System::Drawing::Size(112, 48);
			this->btnImportar->TabIndex = 7;
			this->btnImportar->Text = L"Importar Datos Matriz";
			this->btnImportar->UseVisualStyleBackColor = true;
			// 
			// txtDireccion
			// 
			this->txtDireccion->Enabled = false;
			this->txtDireccion->Location = System::Drawing::Point(127, 48);
			this->txtDireccion->Name = L"txtDireccion";
			this->txtDireccion->Size = System::Drawing::Size(252, 20);
			this->txtDireccion->TabIndex = 8;
			// 
			// groupBox1
			// 
			this->groupBox1->Controls->Add(this->label8);
			this->groupBox1->Controls->Add(this->label7);
			this->groupBox1->Controls->Add(this->txtFilas);
			this->groupBox1->Controls->Add(this->btnGenerar);
			this->groupBox1->Controls->Add(this->txtColumnas);
			this->groupBox1->Location = System::Drawing::Point(3, 85);
			this->groupBox1->Name = L"groupBox1";
			this->groupBox1->Size = System::Drawing::Size(303, 170);
			this->groupBox1->TabIndex = 9;
			this->groupBox1->TabStop = false;
			this->groupBox1->Text = L"Tama�o Matriz";
			// 
			// label8
			// 
			this->label8->AutoSize = true;
			this->label8->Location = System::Drawing::Point(6, 85);
			this->label8->Name = L"label8";
			this->label8->Size = System::Drawing::Size(224, 13);
			this->label8->TabIndex = 2;
			this->label8->Text = L"Ingrese las cantidad de columnas de la matriz:";
			// 
			// label7
			// 
			this->label7->AutoSize = true;
			this->label7->Location = System::Drawing::Point(6, 33);
			this->label7->Name = L"label7";
			this->label7->Size = System::Drawing::Size(197, 13);
			this->label7->TabIndex = 1;
			this->label7->Text = L"Ingrese las cantidad de filas de la matriz:";
			// 
			// txtFilas
			// 
			this->txtFilas->Location = System::Drawing::Point(9, 50);
			this->txtFilas->Name = L"txtFilas";
			this->txtFilas->Size = System::Drawing::Size(100, 20);
			this->txtFilas->TabIndex = 4;
			// 
			// btnGenerar
			// 
			this->btnGenerar->Location = System::Drawing::Point(182, 128);
			this->btnGenerar->Name = L"btnGenerar";
			this->btnGenerar->Size = System::Drawing::Size(115, 36);
			this->btnGenerar->TabIndex = 6;
			this->btnGenerar->Text = L"Generar Tabla";
			this->btnGenerar->UseVisualStyleBackColor = true;
			this->btnGenerar->Click += gcnew System::EventHandler(this, &MyForm::btnGenerar_Click);
			// 
			// txtColumnas
			// 
			this->txtColumnas->Location = System::Drawing::Point(9, 101);
			this->txtColumnas->Name = L"txtColumnas";
			this->txtColumnas->Size = System::Drawing::Size(100, 20);
			this->txtColumnas->TabIndex = 5;
			// 
			// dgvDeterminante
			// 
			this->dgvDeterminante->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->dgvDeterminante->Location = System::Drawing::Point(394, 85);
			this->dgvDeterminante->Name = L"dgvDeterminante";
			this->dgvDeterminante->Size = System::Drawing::Size(516, 294);
			this->dgvDeterminante->TabIndex = 3;
			this->dgvDeterminante->CellContentClick += gcnew System::Windows::Forms::DataGridViewCellEventHandler(this, &MyForm::dataGridView1_CellContentClick);
			// 
			// label6
			// 
			this->label6->AutoSize = true;
			this->label6->Font = (gcnew System::Drawing::Font(L"MV Boli", 18, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label6->Location = System::Drawing::Point(271, 22);
			this->label6->Name = L"label6";
			this->label6->Size = System::Drawing::Size(367, 31);
			this->label6->TabIndex = 0;
			this->label6->Text = L"Determinante de una matriz";
			// 
			// tpEjercicio4
			// 
			this->tpEjercicio4->Location = System::Drawing::Point(4, 22);
			this->tpEjercicio4->Name = L"tpEjercicio4";
			this->tpEjercicio4->Size = System::Drawing::Size(940, 411);
			this->tpEjercicio4->TabIndex = 3;
			this->tpEjercicio4->Text = L"Ejercicio 4";
			this->tpEjercicio4->UseVisualStyleBackColor = true;
			// 
			// btnSalir
			// 
			this->btnSalir->Location = System::Drawing::Point(411, 456);
			this->btnSalir->Name = L"btnSalir";
			this->btnSalir->Size = System::Drawing::Size(162, 36);
			this->btnSalir->TabIndex = 1;
			this->btnSalir->Text = L"Salir del programa";
			this->btnSalir->UseVisualStyleBackColor = true;
			this->btnSalir->Click += gcnew System::EventHandler(this, &MyForm::btnSalir_Click);
			// 
			// MyForm
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(973, 504);
			this->Controls->Add(this->btnSalir);
			this->Controls->Add(this->tabControl1);
			this->Name = L"MyForm";
			this->Text = L"MyForm";
			this->tabControl1->ResumeLayout(false);
			this->tpEjercicio1->ResumeLayout(false);
			this->tpEjercicio1->PerformLayout();
			this->tpEjercicio2->ResumeLayout(false);
			this->tpEjercicio2->PerformLayout();
			this->tpEjercicio3->ResumeLayout(false);
			this->tpEjercicio3->PerformLayout();
			this->Importar->ResumeLayout(false);
			this->Importar->PerformLayout();
			this->groupBox1->ResumeLayout(false);
			this->groupBox1->PerformLayout();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->dgvDeterminante))->EndInit();
			this->ResumeLayout(false);

		}
#pragma endregion
	private: System::Void btnCalcular_Click(System::Object^ sender, System::EventArgs^ e) {

		try
		{
			txtResultado->Text = " " + operacion(Convert::ToInt32(txtMultiplicando->Text), Convert::ToInt32(txtMultiplicador->Text));
		}
		catch (Exception ^ e)
		{
			MessageBox::Show("Se ha encontrado un error ", "Multiplicaci�n ", MessageBoxButtons::OK, MessageBoxIcon::Error);
		}

	}



	private: System::Void button1_Click(System::Object^ sender, System::EventArgs^ e) {

		try 
		{
			int multiplicando; 
			int multiplicador; 
			int resultado = 0;

			multiplicando = Convert::ToInt32(txtMultiplicando->Text);
			multiplicador = Convert::ToInt32(txtMultiplicador->Text);

			for (int i = 1; i <= multiplicador; i++) {
				resultado = resultado + multiplicando;
			}

			txtResultado->Text = " " + resultado ;

		}
		catch (Exception ^ e) 
		{
			MessageBox::Show("Se ha encontrado un error ", "Multiplicaci�n ", MessageBoxButtons::OK, MessageBoxIcon::Error);
		}


	}




		int operacion(int multiplicando, int multiplicador) 
		{
			if (multiplicador == 1) {
				
				return multiplicando;
			}
			else if (multiplicador > 0) {
				
				return multiplicando + operacion(multiplicando, multiplicador - 1);

			}
			else if (multiplicador < 0 ) 
			{

				return -multiplicando + operacion(multiplicando, multiplicador + 1);

			}
		}






private: System::Void btnSalir_Click(System::Object^ sender, System::EventArgs^ e) {
		
		MessageBox::Show("Ha salido del programa con �xito ", "Salir ", MessageBoxButtons::OK, MessageBoxIcon::Information);
		this->Close();

}


#pragma endregion


	   void RestablecerMatriz() {
		   dgvDeterminante ->Rows->Clear();
		   dgvDeterminante ->Columns->Clear();
		   dgvDeterminante ->ColumnHeadersVisible = false;
		   dgvDeterminante ->RowHeadersVisible = false;
	   }

private: System::Void dataGridView1_CellContentClick(System::Object^ sender, System::Windows::Forms::DataGridViewCellEventArgs^ e) {
}
private: System::Void btnGenerar_Click(System::Object^ sender, System::EventArgs^ e) {

		int numFilas; 
		int numColumnas;

		try
		{
			numFilas = Convert::ToInt32(txtFilas->Text);
			numColumnas = Convert::ToInt32(txtColumnas->Text);
		}
		catch (Exception ^ e)
		{
			MessageBox::Show("Se ha encontrado un error ", "Determinante de una matriz ", MessageBoxButtons::OK, MessageBoxIcon::Error);
		}

		RestablecerMatriz();

		if (numColumnas > 0)
		{
			for (int i = 0; i < numColumnas; i ++)
			{
				DataGridViewColumn^ NuevaColumna = gcnew DataGridViewColumn();
				NuevaColumna->Width = 35;

				DataGridViewCell^ cellTemplate = gcnew DataGridViewTextBoxCell();
				NuevaColumna->CellTemplate = cellTemplate;

				dgvDeterminante->Columns->Add(NuevaColumna);
			}

		}

		if (numFilas > 0)
		{
			for(int i = 0; i < numFilas; i++)
			{
				dgvDeterminante->Rows->Add();
			}

		}


}
private: System::Void btnImportartxt_Click(System::Object^ sender, System::EventArgs^ e) {


	ofdImportar ->Filter = "Archivos separados por coma (txt) | *.txt";
	ofdImportar->FileName = "";

	if (ofdImportar->ShowDialog() == System::Windows::Forms::DialogResult::OK) 
	{
		txtDireccionArchivo->Text = ofdImportar->FileName;

		
		array<String^>^ Contenido = File::ReadAllLines(ofdImportar->FileName);
		
		if (Contenido->Length > 0) {

	

	
			BancoPalabras->Items->Add(Contenido);

		}





	}



}
};
}
